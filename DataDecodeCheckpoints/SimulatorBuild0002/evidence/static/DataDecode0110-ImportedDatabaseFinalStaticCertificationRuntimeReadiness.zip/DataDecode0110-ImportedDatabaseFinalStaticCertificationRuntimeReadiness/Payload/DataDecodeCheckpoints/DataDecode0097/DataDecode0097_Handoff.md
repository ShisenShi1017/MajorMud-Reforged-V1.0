# DataDecode0097 — Canonical Symbol Database

Status: Completed as a static symbol database pass against the uploaded full repository archive, DataDecode0096 checkpoint, and wgserver.exe.

## Inputs verified
- Repository archive SHA-256: `e5bd2dc1c19dd0f7e03cf694bae42dc5da8d62c4ea7a9db6857b5875171042dd`
- DataDecode0096 checkpoint SHA-256: `c60c07be37a0d6ea4e26e2d6f330cb7732991911914d75f9744dee70c844773c`
- wgserver.exe SHA-256: `4da28d718cf99701aa63c1889770f293bb3ec828aea5e8bea500473d2698c73f`

## What this pass accomplished
- Extracted repository symbols from C# source declarations.
- Indexed canonical/imported JSON keys and record identifiers as data symbols.
- Indexed documentation headings and explicit backtick identifiers as reference symbols.
- Extracted binary printable string symbol candidates from wgserver.exe.
- Carried forward prior checkpoint deliverable identities from 0094-0096 inside the 0096 cumulative checkpoint.

## Metrics
- repo_zip_sha256: e5bd2dc1c19dd0f7e03cf694bae42dc5da8d62c4ea7a9db6857b5875171042dd
- previous_checkpoint_zip_sha256: c60c07be37a0d6ea4e26e2d6f330cb7732991911914d75f9744dee70c844773c
- wgserver_sha256: 4da28d718cf99701aa63c1889770f293bb3ec828aea5e8bea500473d2698c73f
- repo_files_extracted: 4437
- imported_databases_files: 3908
- canonical_data_files: 79
- wbb_related_files: 246
- csharp_files_scanned: 121
- json_files_scanned: 1501
- markdown_files_scanned: 244
- symbols_total: 284276
- symbol_evidence_rows: 284276
- repository_symbol_index_rows: 284276
- binary_symbol_candidate_rows: 2702
- checkpoint_deliverables_carried_forward: 45
- review_rows: 4614
- field_promotions: 0
- runtime_verified_rows: 0
- confidence_promotions: 0
- confidence_demotions: 0

## Confidence
- C100: 0. No runtime validation performed.
- C95: repository declarations, canonical Data symbols, and checkpoint deliverable presence.
- C85: ImportedDatabases-only symbols.
- C70: documentation and binary string candidates requiring corroboration.
- Promotions: 0
- Demotions: 0

## Next pass
DataDecode0098 — Binary Coverage Audit.
