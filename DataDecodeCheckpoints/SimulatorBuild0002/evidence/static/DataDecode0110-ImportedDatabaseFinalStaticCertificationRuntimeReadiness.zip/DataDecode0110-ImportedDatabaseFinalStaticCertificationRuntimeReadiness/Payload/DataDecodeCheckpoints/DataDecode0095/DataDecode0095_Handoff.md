# DataDecode0095 — String & Message Resolution (Reexecuted)

Status: completed from available uploaded corpus.

## Inputs analyzed
- Full repository archive: `MajorMud-Reforged-V1.0-main (1).zip`
- Reexecuted 0094 checkpoint: `DataDecode0094-CompleteCrossReferenceGraph-Reexecuted.zip`
- Runtime static string authority: `wgserver.exe`

## What this pass accomplished
DataDecode0095 extracted printable ASCII and UTF-16LE strings from `wgserver.exe`, classified likely message candidates using static string evidence, correlated strings against the verified DataDecode0094 graph labels, and recorded repository text corroboration where exact printable strings appeared in repository text files.

No runtime execution was performed. No field promotions were made. All string-to-record relationships remain static candidates unless later runtime validation promotes them.

## Metrics
- Repository files extracted: 4437
- ImportedDatabases files: 3908
- WBB-related files: 246
- Graph nodes carried forward: 1163
- Graph edges carried forward: 2680
- Printable ASCII strings: 5916
- Printable UTF-16LE strings: 26
- Total strings cataloged: 5942
- Message candidate strings: 204
- String graph edges: 188
- String evidence rows: 188
- String-record links: 107
- Repository text corroboration hits: 81
- Conflict/review rows: 106
- Field promotions: 0
- Runtime verified rows: 0

## Data Confidence Summary
- C100: 0
- C95: static string candidates only
- C85: unchanged
- C70: unchanged
- Promotions: 0
- Demotions: 0

## Next pass
DataDecode0096 — Resource Verification will verify external resources, WBB assets, imported databases, duplicates, orphans, and repository coverage.
