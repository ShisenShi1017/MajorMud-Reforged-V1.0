@echo off
echo DataDecode0101 is a research-only cumulative package.
echo No /Data files are modified by this package.
