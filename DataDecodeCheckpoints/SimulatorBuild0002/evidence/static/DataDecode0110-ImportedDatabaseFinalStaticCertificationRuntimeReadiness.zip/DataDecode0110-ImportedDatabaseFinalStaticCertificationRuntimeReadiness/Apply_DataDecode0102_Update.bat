@echo off
echo DataDecode0102 payload archive. Apply manually after review.
