namespace MajorMud.Reforged.Core.Validation;

public interface IValidator<in T>
{
    ValidationResult Validate(T value);
}
