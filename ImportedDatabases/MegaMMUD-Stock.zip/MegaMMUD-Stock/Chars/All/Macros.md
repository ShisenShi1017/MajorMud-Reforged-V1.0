112:0:0:0:sys goto sil^M
113:0:0:0:sys goto kha^M
114:0:0:0:sys goto rhu^M
115:0:0:0:sys goto lost^M
116:0:0:0:sys goto new^M
